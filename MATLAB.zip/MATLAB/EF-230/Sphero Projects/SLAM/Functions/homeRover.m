%%Home
%Purpose: Send the rover to its datum to re center its coordinates.
%Input: Starting X position, Starting Y position, Starting Heading, Rover Name
%Output: amHome, outputs true when homing is complete.

function [amHome] = homeRover(myX,myY,myHeading,rvrName)

%Create variables for storing our key colors
myGreen = [0 255 0];
myRed = [255 0 0];

%Point the rover towards where the homing plate should be.


%Case 1: Rover rolls over homing plate from green to red.
%Case 2: Rover rolls over homing plate from red to green.
%Case 3: Rover rolls over homing plate through green never touching red.
%Case 4: Rover rolls over homing plate through red never touching green.



end