%%Circle Map
%NOTE: Does not account for distances outside effective range
%could store points in a 3 dimensional matrix with angle
rvrName = rvr
coords = zeros(2,360)

for i = 1:361 %iterate for every degree in a circle
    rvr.turnAngle(1); %rotate clockwise 1 degree
    [x,y] = mapNewPoint(i,0,0,rvrName); %get the coordinate of object being observed
    x = int8(x); %convert the x distance to a integer
    y = int8(y); %convert the y distance to an integer
    coords(1,i) = x; %store the x coordinate
    coords(2,i) = y; %store the y coordinate
end

%Find the maximum value in both x and Y coordinate and use this to make a
%map.
mapDimensions = [max(coords(1,1:360)) max(coords(2,1:360))];
myMap = zeros(mapDimensions(1),mapDimensions(2));

%%Fill the map
%Edit the active coordinate of map at the xy values in coords at column i.
%Set this coordinate to 1 to indicate it has been seen.
for i = 1:360
    myMap(coords(1,i),coords(2,i)) = 1;
end



