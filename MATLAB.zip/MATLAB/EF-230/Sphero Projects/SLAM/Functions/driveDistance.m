%%Drive Distance
%Purpose: A simple command to drive forward a given distance using the
%setDriveSpeed command.
%Inputs: Distance to drive(m), Time to drive distance(s), name of rover object
%Usage: driveDistance(Distance,Time,Name)

function driveDistance(myDist,myTime,rvrName)
mySpeed = myDist ./ myTime;
rvrName.setDriveSpeed(mySpeed);
pause(myTime);
rvrName.setDriveSpeed(0);
end