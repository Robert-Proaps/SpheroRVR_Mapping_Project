%% Distance to point
%Purpose: Return the distance to a coordinate.
%Inputs: Target XY and Current XY where ordered pairs are stored in 1x2
%matrices
%Outputs: distance to target in units common to inputs.
%Usage: dist2point([Target X, Target Y],[starting X, starting Y])

function [myDist] = dist2point(target,origin)
myDist = sqrt((target(1) - origin(1)) .^2 + (target(2) - origin(2)) .^ 2);
end