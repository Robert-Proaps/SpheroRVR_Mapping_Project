%%Point Mapping Function
%Purpose: Add a new point to the map
%Input: Heading, and Position, Name
%Output: Map Point Coordinates, Returns NaN,NaN if distance is outside
%effective range
%Usage: mapNewPoint(heading(deg),posX,posY,rvrName)

function [pointX,pointY] = mapNewPoint(heading,posX,posY,rvrName) %Take in the current heading, current coordinate, and the rover object name
myDistance = rvrName.getDistance(); %Read the distance sensor
if myDistance >= 150
    pointX = NaN;
    pointY = NaN;
    return

if heading == 0 || heading == 90 || heading == 180 || heading == 270 %if the heading is cardinal then just set the intermediate point to the distance
    if heading == 0
        IPX = myDistance;
        IPY = 0;
    elseif heading == 90
        IPX = 0;
        IPY = myDistance;
    elseif heading == 180
        IPX = 0 - myDistance;
        IPY = 0;
    elseif heading == 270
        IPX = 0;
        IPY = 0 - myDistance;
    end
elseif heading > 0 && heading < 90 % if the heading is in quadrant 1 use this trig
    IPX = myDistance * cos(heading);
    IPY = myDistance * sin(heading);
elseif heading > 90 && heading < 180 %if the heading is in quadrant 2 use this trig
    IPX = myDistance * cos(180 - (heading - 90));
    IPY = myDistance * sin(180 - (heading - 90));
elseif heading > 180 && heading < 270 %if the heading is in quadrant 3 use this trig
    IPX = (myDistance * cos(heading - 180)) * -1;
    IPY = (myDistance * sin(heading - 180)) * -1;
elseif heading > 270 && heading < 360 %if the heading is in quadrant 4 use this trig
    IPX = (myDistance * cos(heading - 270)) * -1;
    IPY = (myDistance * sin(heading - 270)) * -1;
       
end

pointX = posX + IPX; %assign output for x
pointY = posY + IPY; %assign output for y



end